function report(element){
    alert("Loading weather report...")
}

function hide(element){
    // var cookie = document.querySelector(element)
    // cookie.remove()
    document.querySelector(element).remove()
}